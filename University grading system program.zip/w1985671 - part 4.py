# I declare that my work contains no examples of misconduct, such as plagiarism, or collusion.

# Any code taken from other sources is referenced within my code solution.

# Student ID: w1985671 
 
# Date: 2023.04.20

print('''
-------------------------------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------program to predict student progression outcome at the end of each academic year-------------------------------------------
-------------------------------------------------------------------------------------------------------------------------------------------------------------------
''')

def calculate_total():
    total = pass_credit + defer_credit + fail_credit
    return total

dictionary = {}

while True:
        
    try:
        student_id = input('\nPlease enter your student id(e.g.w1234567):')
        pass_credit = int(input('Please enter your credit at pass:'))
        defer_credit = int(input('Please enter your credit at defer:'))
        fail_credit = int(input('Please enter your credit at fail:'))

        total_credit = calculate_total()

        if not (pass_credit in [0,20,40,60,80,100,120] and defer_credit in [0,20,40,60,80,100,120] and fail_credit in [0,20,40,60,80,100,120]):
            print('Out of range')

        elif total_credit != 120:
            print('Total incorrect')

        elif pass_credit == 120:
            print('Progress')
            dictionary[student_id]=['Process - ',pass_credit,defer_credit,fail_credit]
            
        elif pass_credit == 100:
            print('Progress (module trailer)')
            dictionary[student_id]=['Progress (module trailer) - ',pass_credit,defer_credit,fail_credit]
            
        elif pass_credit + defer_credit >= 60 and pass_credit + defer_credit <= 120:
            print('module retriever')
            dictionary[student_id]=['Module retriver - ',pass_credit,defer_credit,fail_credit]
            
        elif fail_credit >= 80 and fail_credit <= 120:
            print('Exclude')
            dictionary[student_id]=['Exculde - ',pass_credit,defer_credit,fail_credit]
            
    except ValueError:
        print('Integer required')

    print('\nWould you like to enter another set of data?')
    proceed =input("Enter 'y' for yes or 'q' to quit and view results:")
    new_proceed = proceed.lower()

    if new_proceed == 'y':
        continue

    elif new_proceed == 'q':
        break

    else:
        print('Please select a valid option')
        
        while new_proceed != 'y':
            print('\nWould you like to enter another set of data?')
            proceed =input("Enter 'y' for yes or 'q' to quit and view results:")
            new_proceed = proceed.lower()

print('''
-------------------------------------------------------------------------------------------------------------------------------------------------------------------
''')

print('part 4:')
for (k,v) in dictionary.items():
    print(k,':',v[0],v[1],',',v[2],',',v[3])
